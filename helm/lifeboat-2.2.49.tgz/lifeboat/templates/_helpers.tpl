{{/*
Expand the name of the chart.
*/}}
{{- define "lifeboat.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified app name.
*/}}
{{- define "lifeboat.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "lifeboat.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "lifeboat.labels" -}}
helm.sh/chart: {{ include "lifeboat.chart" . }}
{{ include "lifeboat.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "lifeboat.selectorLabels" -}}
app.kubernetes.io/name: {{ include "lifeboat.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Container image. On AMD the tag comes from gpu.amd.imageTag, because the ROCm
image is a DIFFERENT image rather than a different configuration of the same
one: `latest` is the CUDA build and will not run on an AMD GPU (a container
image selects on CPU architecture only, so one tag cannot serve both vendors).
An explicit image.tag still wins, so a pinned deployment is never overridden.
*/}}
{{- define "lifeboat.image" -}}
{{- $tag := "" -}}
{{- if and (eq .Values.gpu.vendor "lite") (or (not .Values.image.tag) (eq .Values.image.tag "latest")) -}}
{{- /* :latest is the 17.5 GB accelerator image. Pulling it onto a node picked
       for being small is the most likely mistake here, so the vendor switch
       moves the tag rather than relying on the operator to remember. */ -}}
{{- $tag = "lite" -}}
{{- else if and (eq .Values.gpu.vendor "amd") (or (not .Values.image.tag) (eq .Values.image.tag "latest")) -}}
{{- $tag = default "latest-rocm" .Values.gpu.amd.imageTag -}}
{{- else -}}
{{- $tag = default .Chart.AppVersion .Values.image.tag -}}
{{- end -}}
{{- printf "%s:%s" .Values.image.repository $tag -}}
{{- end -}}

{{/*
Extended resource for one GPU. Defaults per vendor so a vendor switch does not
also require knowing the device-plugin resource name; an explicit
gpu.resourceName always wins.
*/}}
{{/*
Whether this deployment asks the scheduler for a GPU at all. False for lite:
requesting an extended resource no node advertises leaves the pod Pending
forever, and the cause is not visible in the pod's own events.
*/}}
{{- define "lifeboat.wantsGpu" -}}
{{- if and (ne .Values.gpu.vendor "lite") (gt (int .Values.gpu.count) 0) -}}
true
{{- end -}}
{{- end -}}

{{- define "lifeboat.gpuResourceName" -}}
{{- if .Values.gpu.resourceName -}}
{{- .Values.gpu.resourceName -}}
{{- else if eq .Values.gpu.vendor "amd" -}}
amd.com/gpu
{{- else -}}
nvidia.com/gpu
{{- end -}}
{{- end -}}

{{- define "lifeboat.adminSecretName" -}}
{{- if .Values.admin.existingSecret -}}
{{- .Values.admin.existingSecret -}}
{{- else -}}
{{- printf "%s-admin" (include "lifeboat.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "lifeboat.dataClaimName" -}}
{{- if .Values.persistence.existingClaim -}}
{{- .Values.persistence.existingClaim -}}
{{- else -}}
{{- printf "%s-data" (include "lifeboat.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "lifeboat.modelsClaimName" -}}
{{- if .Values.models.existingClaim -}}
{{- .Values.models.existingClaim -}}
{{- else -}}
{{- printf "%s-models" (include "lifeboat.fullname" .) -}}
{{- end -}}
{{- end -}}
