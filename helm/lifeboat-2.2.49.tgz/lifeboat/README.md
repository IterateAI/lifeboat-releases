# Lifeboat Helm chart

A minimal Helm chart that deploys the same single-container Lifeboat image
(`iterateai/lifeboat:latest`) as the docker-run path, with one important
difference baked in by default: **GPU access goes through CDI, not the
legacy `nvidia.com/gpu` extended resource alone**. CDI bakes the NVIDIA
device list into the pod's OCI spec, so device permissions survive cgroup
re-application — the cause of the in-container `Failed to initialize NVML:
Unknown Error` that appears ~24h after start on hosts where unattended
upgrades / systemd reloads trigger.

The chart deploys the **rolling `:latest` image** (`image.tag=latest`,
`pullPolicy=Always`), so re-uploading the chart + `helm upgrade` always picks
up the newest build. Pin a specific build with `--set image.tag=<version>`.

## Install (hosted chart)

The chart is published as a single rolling tarball at
`https://license.interplay.iterate.ai/lifeboat/lifeboat-latest.tgz`
(built automatically by `./build.sh` → `dist/lifeboat-latest.tgz`).

**A) Direct tarball** — simplest, nothing to add:

```bash
helm install lifeboat https://license.interplay.iterate.ai/lifeboat/lifeboat-latest.tgz \
  --namespace lifeboat --create-namespace \
  --set admin.password='CHANGE-ME' \
  --set gpu.count=1
```

**B) As a Helm repo** — lets you `helm upgrade` later (needs `index.yaml`
hosted alongside the tarball):

```bash
helm repo add lifeboat https://license.interplay.iterate.ai/lifeboat
helm repo update
helm install lifeboat lifeboat/lifeboat \
  --namespace lifeboat --create-namespace \
  --set admin.password='CHANGE-ME' \
  --set gpu.count=1
```

To upgrade after a new build is uploaded:
`helm repo update && helm upgrade lifeboat lifeboat/lifeboat` (or re-run the
direct-tarball command with `helm upgrade --install`).

> **`admin.password` is required** (or `admin.existingSecret`) — the chart
> refuses to render without one. There is **no `licensing.licenseKey` value**:
> the chart cannot activate a license, because activation is an API call the
> control plane makes at runtime, not an env var. Activate in the dashboard
> (or `POST /api/license/activate`) once the pod is up; air-gapped clusters
> upload a signed `.lic` through the same dialog.


## Install (from a repo checkout)

```bash
helm install lifeboat ./helm/lifeboat \
  --namespace lifeboat --create-namespace \
  --set admin.password='LifeboatAdmin411*'
```

Custom values:

```bash
helm install lifeboat ./helm/lifeboat \
  -f my-values.yaml \
  --set image.tag=2.1.130 \
  --set admin.existingSecret=lifeboat-admin
```

## Prerequisites

1. A node with an NVIDIA GPU and the host driver installed.
2. NVIDIA Container Toolkit (`nvidia-ctk`) installed on the host.
3. The CDI spec generated + boot-refresh systemd unit installed on every
   GPU node. Same image, no extra scripts:

   ```bash
   docker run --rm --privileged --pid=host \
       iterateai/lifeboat:latest host-setup
   ```

   This nsenter's into the host's namespaces, runs nvidia-ctk to
   generate `/etc/cdi/nvidia.yaml`, and installs
   `lifeboat-cdi-refresh.service` so reboots and driver upgrades pick
   up new library paths automatically.

4. `nvidia-device-plugin` installed on the cluster in CDI mode (>=0.15):

   ```bash
   helm upgrade --install nvdp nvdp/nvidia-device-plugin \
     -n nvidia-device-plugin --create-namespace \
     --set deviceListStrategy=cdi-annotations \
     --set cdi.enabled=true
   ```

   OR the NVIDIA GPU Operator with CDI enabled.

If your cluster requires a custom container runtime class for GPU pods,
set `gpu.runtimeClassName=nvidia`.

## What this chart deploys

- One Deployment (default `replicas: 1`, strategy `Recreate`) running the
  all-in-one Lifeboat image.
- A PVC for `/opt/lifeboat/.lifeboat` (the DB, JWT secret, config).
- The models directory (`/models`) backed by hostPath / PVC / existingClaim
  / emptyDir — pick via `models.mode`.
- A ClusterIP Service on port 8001 (control plane + inference proxy) and
  8002 (node agent).
- Optional Ingress on the control-plane port.
- A Secret holding admin bootstrap credentials.
- A tmpfs `/dev/shm` (sized via `shmSize`, default 8 GiB) for engine IPC.

## Customizing

See `values.yaml` for the full set of knobs. The fields most users touch:

| Key                       | Default               | Notes |
|---------------------------|-----------------------|-------|
| `image.tag`               | `Chart.appVersion`    | pin a specific Lifeboat version |
| `admin.password`          | *(required)*          | OR set `admin.existingSecret` |
| `gpu.count`               | `1`                   | per-replica GPU count |
| `gpu.cdi.enabled`         | `true`                | leave on; see warning in NOTES if you disable |
| `gpu.cdi.deviceName`      | `all`                 | `0`, `0-1`, etc. for partial pinning |
| `persistence.size`        | `20Gi`                | `/opt/lifeboat/.lifeboat` volume size |
| `models.mode`             | `hostPath`            | `hostPath` \| `pvc` \| `existingClaim` \| `emptyDir` |
| `models.hostPath.path`    | `/home/iterate-dev/models` | host directory to mount |
| `shmSize`                 | `8Gi`                 | bump for very large MoE models |
| `service.type`            | `ClusterIP`           | `NodePort`/`LoadBalancer` to expose |
| `ingress.enabled`         | `false`               | flip on + supply `hosts` |
| `gpu.runtimeClassName`    | `""`                  | set to the Kata/CoCo CC runtime class (e.g. `kata-qemu-nvidia-gpu-snp`) for confidential computing |
| `confidentialComputing.mode` | `""` (→ `auto`)    | `off` \| `auto` \| `require`. Licensed add-on — only engages when the license entitles it. See README "Confidential Computing". |

## Why the GPU defaults look the way they do

The chart sets both:

1. `cdi.k8s.io/gpu: nvidia.com/gpu=all` as a pod annotation, AND
2. `resources.limits.nvidia.com/gpu: <count>` so the k8s scheduler still
   places the pod on a node with GPUs.

The annotation is what tells the NVIDIA Container Toolkit / device plugin
to inject the devices via CDI. The resource request alone (without the
annotation, on a non-CDI device-plugin) replicates the `--gpus all` shape
that loses the GPU on cgroup re-apply.

If you're on a cluster where the device plugin already runs in CDI mode
and uses CDI annotations automatically, the explicit annotation is
redundant but harmless.

## Upgrading

```bash
helm upgrade lifeboat ./helm/lifeboat -n lifeboat --reuse-values
```

The PVC at `/opt/lifeboat/.lifeboat` carries the DB, server configs, and
JWT secret across image upgrades — same as the `lifeboat-data` named
volume in the docker path.

## AMD GPUs (ROCm)

Set `gpu.vendor=amd`. The chart then switches the image, the extended resource
and the pod settings ROCm requires — a one-value change:

```sh
helm install lifeboat lifeboat/lifeboat \
  --set gpu.vendor=amd \
  --set admin.password='CHANGE-ME'
```

| Rendered as | NVIDIA | AMD |
|---|---|---|
| image | `iterateai/lifeboat:latest` | `iterateai/lifeboat:latest-rocm` |
| GPU resource | `nvidia.com/gpu` | `amd.com/gpu` |
| CDI annotation | yes | **no** (ROCm has no CDI) |
| `runtimeClassName` | if configured | **not set** |
| `hostIPC` | not set | **true (required)** |
| seccomp | cluster default | **Unconfined** |
| `supplementalGroups` | none | `[44, 105]` (video, render) |

### Cluster prerequisites

* The **AMD GPU device plugin** (or the AMD GPU Operator) must be running, so
  nodes advertise `amd.com/gpu` and the plugin injects `/dev/kfd` and
  `/dev/dri` into the pod. The NVIDIA container toolkit is not involved.
* ROCm 6.3+ with the `amdgpu` kernel driver on the GPU nodes.
* `x86_64` nodes — ROCm has no arm64 build.

### Why hostIPC and Unconfined are not optional

`hostIPC: true` is a ROCm requirement, not hardening preference: with a private
IPC namespace the engine dies at its **first** GPU allocation with an HSA-level
`Memory critical error ... Reason: Memory in use`, which names neither IPC nor
memory and looks like a driver fault. Measured on an Instinct MI210.
`seccompProfile: Unconfined` is AMD's documented requirement for ROCm
containers (userspace DMA ioctls). Both are togglable under `gpu.amd.*` if your
cluster policy forbids them, but the deployment will not serve without them.

### Pick the image for your GPU generation

Engine kernels are compiled per CDNA generation, because the FP8 number format
differs between CDNA3 and CDNA4 — one binary cannot be correct for both:

| `gpu.amd.imageTag` | GPUs |
|---|---|
| `latest-rocm` (default) | Instinct MI210 / MI250 |
| `amd-mi300x` | Instinct MI300X / MI325X |

The container warns at startup if it is running on a GPU it was not built for.
The bundled GGUF engine is a fat binary and covers every generation.

### Not available on AMD

GPU confidential computing requires an NVIDIA CC-mode GPU in a confidential VM
and is **disabled automatically** on AMD — an AMD EPYC SEV-SNP host satisfies
only the CPU half. `confidentialComputing.mode=require` will not block server
starts there; it is downgraded with a logged explanation.

## The pod runs as uid 999 — do not remove it

`securityContext.runAsUser: 999` is load-bearing. The image has no `USER`
directive, so without it the container runs as root, and because
`containerSecurityContext` drops ALL capabilities (including
`CAP_DAC_OVERRIDE`) root loses the right to ignore file modes. `/opt/lifeboat`
is mode `0750` owned by the `lifeboat` user, so root cannot even traverse it
and PID 1 dies with:

```
[FATAL tini (7)] exec /opt/lifeboat/docker-entrypoint.sh failed: Permission denied
```

which points at a file that is itself world-executable — a misleading error.
This affects both vendors and was verified on a live cluster: without it the
pod CrashLoopBackOffs, with it the pod is Ready in ~40s.

`runAsGroup` is deliberately **not** set: `useradd -r` produced gid 999 in the
CUDA image but gid 108 in the ROCm image (its base already occupies 999), so
pinning a group would break one of them. Traversal succeeds via the owner bits
once the uid is right. `fsGroup` only needs to be consistent — the kubelet
chowns the volume to it and adds it as a supplementary group.

## CPU-only and edge nodes: `gpu.vendor: lite`

```sh
helm install lifeboat ./helm/lifeboat \
  --set gpu.vendor=lite \
  --set admin.password='<a real password>'
```

Deploys the Lite image — control plane + GGUF engine, ~720 MB against the
accelerator images' 17–28 GB. It needs **no GPU, no device plugin, no runtime
class and no CDI spec**, and the chart drops all of them: `helm template` with
`gpu.vendor=lite` renders zero `nvidia.*` and zero `amd.*` references and
requests no extended resource. Requesting one a node does not advertise would
leave the pod Pending forever with nothing in its own events to explain why.

An integrated or older GPU can still be used, through Vulkan, if you pass the
render node in. That is a separate explicit step — Kubernetes will not hand a
pod `/dev/dri` on its own.

Lite carries no tensor engine, so the `lifeboat_*` optimization suite does not
apply. Everything above the engine — load balancing, routing modes, the full
API surface, licensing, audit, the console — works unchanged.
`GET /api/hardware/profile` reports which engine a node resolved to and why,
and sizes models against that node's real memory, including a container limit.

Three defaults are tuned for small nodes and each yields to an explicit value:
`LIFEBOAT_TTS_MAX_CONCURRENCY=1` (llama-tts reloads the model on every request,
~4.2 GB RSS each, so two at once is the OOM killer on an 8 GB node), the LB
queue ON (on a node serving single-digit tokens/sec a 503 on the second
request is a worse answer than a wait), and a 4096-token per-request context
(`lite.contextPerRequest`) because the KV cache competes with the weights and
the OS for one pool of memory.

Sizing: on an 8 GB node, 1.5B–4B at 4-bit is comfortable and 8B is the ceiling;
14B does not fit. Expect time-to-first-token, rather than generation speed, to
dominate on a low-core node.
